<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use App\StudentRecord;

class DynamicController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
        return view('dynamic.index');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //



        //
            $this->validate($request, [
            'name'    =>  'required',
            'father_name'     =>  'required',
            'sid'     =>  'required',
            'address'     =>  'required',
            'mobile'     =>  'required'
        ]);
        $studentRecord = new StudentRecord([
            'name'    =>  $request->get('name'),
            'father_name'     =>  $request->get('father_name'),
            'mother_name'    =>  $request->get('mother_name'),
            'class'     =>  $request->get('class'),
            'sid'    =>  $request->get('sid'),
            'address'     =>  $request->get('address'),
            'mobile'    =>  $request->get('mobile'),
            'email'     =>  $request->get('email')
        ]);
        $studentRecord->save();
        return redirect()->route('dynamic.index')->with('success record', 'Data Added');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show()
    {
        //
        return view('dynamic.show');
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //;
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }


     public function aboutus()
    {
        //
        return view('dynamic.aboutus');
    }

       public function aboutme()
    {
        //
        return view('dynamic.aboutme');
    }


     public function contactus()
    {
        //
        return view('dynamic.contactus');
    }

     public function services()
    {
        //
        return view('dynamic.services');
    }

      public function registration()
    {
        //
        return view('dynamic.registration');
    }
      public function display()
    {
        //
        return view('dynamic.display');
    }
}
