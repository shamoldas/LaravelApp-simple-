<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class StudentRecord extends Model
{
    //
     protected $fillable = ['name', 'father_name','mother_name','class','sid',
	'address','mobile','email'];
}
