@extends('includes.layout')
@section('content')

<div class="page-content">
   <h3><strong><div class="block-title">ShamolDas</div></strong></h3>
    <div class="block block-strong">
    	<p><strong>I am simple person but difficult & Individuality.computer science & engineering student at HSTU.</strong></p><br>
    	<p>develop ownself that need to invest time to learning something new.
I enjoy the simple things in life. Being happy is a state of mind.I always look toward the next best thing. </p>

      <p>Framework7 - is a free and open source HTML mobile framework to develop hybrid mobile apps or web apps with iOS or Android (Material) native look and feel. It is also an indispensable prototyping apps tool to show working app prototype as soon as possible in case you need to. Framework7 is created by Vladimir Kharlampidi (iDangero.us).</p>
    
    
    </div>
  </div>
  @endsection