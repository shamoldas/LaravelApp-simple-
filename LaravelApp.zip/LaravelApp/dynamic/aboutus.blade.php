@extends('includes.layout')
@section('content')

<div class="page-content">
    <h3><center><strong></strong><div class="block-title">Welcome to Laravel Framework7</div></strong></center></h3>
    <div class="block block-strong">


    	

    	   <p>
A small business needs a professional digital outlet to process customer needs and deliver the impeccable business experience. Digital is the place to be if you’re planning to connect with customers from all over the world, instead of limiting yourself to a single city or a country. In the early 2000s, the web wasn’t yet so developed, and business websites were rather simple; a little bit of business information, and contact details on how to get in touch. These days, however, the web is a powerful stronghold where business can be concluded directly from a mobile device, without having to move from your couch. And for this kind of diversity, a business website needs to have great and dynamic features, but also a design that can complement those capabilities.
</p>
      <p>Framework7 - is a free and open source HTML mobile framework to develop hybrid mobile apps or web apps with iOS or Android (Material) native look and feel. It is also an indispensable prototyping apps tool to show working app prototype as soon as possible in case you need to. Framework7 is created by Vladimir Kharlampidi (iDangero.us).</p>
      <p>The main approach of the Framework7 is to give you an opportunity to create iOS and Android (Material) apps with HTML, CSS and JavaScript easily and clear. Framework7 is full of freedom. It doesn't limit your imagination or offer ways of any solutions somehow. Framework7 gives you freedom!</p>
      <p>Framework7 is not compatible with all platforms. It is focused only on iOS and Android (Material) to bring the best experience and simplicity.</p>
      <p>Framework7 is definitely for you if you decide to build iOS and Android hybrid app (Cordova or PhoneGap) or web app that looks like and feels as great native iOS or Android (Material) apps.</p>
    </div>
  </div>
  @endsection