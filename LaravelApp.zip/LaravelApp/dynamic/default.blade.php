<meta name="description" content="@yield('description')">

<title>@yield('title') - YourAppName</title>

{{-- Title --}}
@section('title', 'Home')

{{-- Description --}} 
@section('description', 'Hello, this is our brand new website!')

{{-- Title --}}
@section('title', 'About')

{{-- Description --}} 
@section('description', 'Hello, this is a great place to get to know more about us!')

{{-- Title --}}
@section('title', 'Services')

{{-- Description --}} 
@section('description', 'Hello, this is where we tell you about all of the graet services we provide for you!')