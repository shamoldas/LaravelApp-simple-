@extends('includes.layout')

@section('content')

<div class="row">
 <div class="col-md-12">
  <br />
  <h3 align="center">Student Record Data</h3>
  <br />
  @if($message = Session::get('success'))
  <div class="alert alert-success">
   <p>{{$message}}</p>
  </div>
  @endif
  <div align="right">
   <a href="{{url('dynamic')}}" class="btn btn-primary">Home</a>

   <br />
   <br />
  </div>
  <table class="table table-bordered table-striped">
   <tr>
    <th>Name</th>
    <th>Father Name</th>
    <th>Mother Name</th>
    <th>Class/Degree</th>
    <th>Student ID</th>
    <th>Address</th>
    <th>Mobile No</th>
    <th>Email</th>
   </tr>
   @foreach($studentRecords as $row)
   <!--foreach($studentRecords as $row)-->
   <tr>
    <td>{{$row['name']}}</td>
    <td>{{$row['father_name']}}</td>
    <td>{{$row['mother_name']}}</td>
    <td>{{$row['class']}}</td>
    <td>{{$row['sid']}}</td>
    <td>{{$row['address']}}</td>
     <td>{{$row['mobile']}}</td>
    <td>{{$row['email']}}</td>      
  </tr>
   @endforeach
  </table>
 </div>
</div>
  

@endsection
