
@extends('includes.layout')

@section('content')
<div class="row">
 <div class="col-md-12">
  <br />
  <h3 aling="center">Add Record Data</h3>
  <br />
  @if(count($errors) > 0)
  <div class="alert alert-danger">
   <ul>
   @foreach($errors->all() as $error)
    <li>{{$error}}</li>
   @endforeach
   </ul>
  </div>
  @endif
  @if(\Session::has('success'))
  <div class="alert alert-success">
   <p>{{ \Session::get('success') }}</p>
  </div>
  @endif

  <form method="post" action="{{url('studentRecord')}}">
   {{csrf_field()}}
   <div class="form-group">
    <input type="text" name="name" class="form-control" placeholder="Enter Your Name" />
   </div>
   <div class="form-group">
    <input type="text" name="father_name" class="form-control" placeholder="Enter Father Name" />
   </div>

  <div class="form-group">
    <input type="text" name="mother_name" class="form-control" placeholder="Enter Mother Name" />
   </div>
  <div class="form-group">
    <input type="text" name="class" class="form-control" placeholder="Enter Class/Degree" />
   </div>
  <div class="form-group">
    <input type="text" name="sid" class="form-control" placeholder="Enter Student ID" />
   </div>
  <div class="form-group">
    <input type="text" name="address" class="form-control" placeholder="Enter Address" />
  </div>
   <div class="form-group">
    <input type="text" name="mobile" class="form-control" placeholder="Enter Cell/Mobile Number" />
   </div>
  <div class="form-group">
    <input type="email" name="email" class="form-control" placeholder="Enter Email" />
   </div>


   <div class="form-group">
    <input type="submit" class="btn btn-primary" />
    <a href="{{url('display')}}" class="btn btn-primary">Display</a>
     <a href="{{url('show')}}" class="btn btn-primary">Show</a>
    <a href="{{url('dynamic')}}" class="btn btn-primary">Home</a>
   </div>
  </form>
 </div>
</div>
@endsection
