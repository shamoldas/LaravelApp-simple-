@extends('master')

@section('content')

<div class="row">
 <div class="col-md-12">
  <br />
  <h3 align="center">Student Record Data</h3>
  <br />
  @if($message = Session::get('success'))
  <div class="alert alert-success">
   <p>{{$message}}</p>
  </div>
  @endif
  <div align="right">
   <br />
   <br />
  </div>
  <table class="table table-bordered table-striped">
   <tr>
    <th>Name</th>
    <th>Father Name</th>
    <th>Mother Name</th>
    <th>Class/Degree</th>
    <th>Student ID</th>
    <th>Address</th>
    <th>Mobile No</th>
    <th>Email</th>
    <th>Edit</th>
    <th>Delete</th>
   </tr>
   @foreach($studentRecords as $row)
   <!--foreach($studentRecords as $row)-->
   <tr>
    <td>{{$row['name']}}</td>
    <td>{{$row['father_name']}}</td>
    <td>{{$row['mother_name']}}</td>
    <td>{{$row['class']}}</td>
    <td>{{$row['sid']}}</td>
    <td>{{$row['address']}}</td>
     <td>{{$row['mobile']}}</td>
    <td>{{$row['email']}}</td>
    <td><a href="{{action('StudentRecordController@edit', $row['id'])}}" class="btn btn-warning">Edit</a></td>
    <td>
     <form method="post" class="delete_form" action="{{action('StudentRecordController@destroy', $row['id'])}}">
      {{csrf_field()}}
      <input type="hidden" name="_method" value="DELETE" />
      <button type="submit" class="btn btn-danger">Delete</button>
     </form>
    </td>
   </tr>
   @endforeach
  </table>
 </div>
</div>
<script>
$(document).ready(function(){
 $('.delete_form').on('submit', function(){
  if(confirm("Are you sure you want to delete it?"))
  {
   return true;
  }
  else
  {
   return false;
  }
 });
});
</script>
@endsection
