{{-- Header --}}
<header class="jumbotron text-center">
   <h1>YourApp</h1>
   <p>Welcome to our greate website, where we provide amazing services</p>
   <a href="{{url('aboutus')}}" class="btn btn-primary">Learn More About Us</a>
</header>


<li class="nav-item{{Request::is('/') ? ' active' : ''}}">
   <a class="nav-link" href="/">
      Home @if(Request::is('/')) @include('includes.navbar') @endif
   </a>
</li>
<li class="nav-item{{Request::is('about') ? ' active' : ''}}">
   <a class="nav-link" href="/about">
      About @if(Request::is('about')) @include('includes.sr_navbar') @endif
   </a>
</li>
<li class="nav-item{{Request::is('services') ? ' active' : ''}}">
   <a class="nav-link" href="/services">
      Services @if(Request::is('services')) @include('includes.sr_navbar') @endif
   </a>
</li>